
#ifdef __EMSCRIPTEN__

#include "./Arduino.h"

SerialEmulation Serial;
SerialEmulation Serial1;
SerialEmulation Serial2;
SerialEmulation Serial3;

#endif